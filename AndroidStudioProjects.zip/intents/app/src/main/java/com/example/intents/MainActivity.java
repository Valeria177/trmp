package com.example.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText textEntry;
    private Button changeActivityButton;
    private Button changeActivityButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        changeActivityButton = findViewById(R.id.change_activity);
        textEntry = findViewById(R.id.ed_text_entry);
        changeActivityButton2 = findViewById(R.id.change_activity3);

        changeActivityButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                String textEntered = textEntry.getText().toString();
                Context context = MainActivity.this;
                Class destinationActivity = MainActivity2.class;

                Intent mainActivityIntent = new Intent(context, destinationActivity);
                mainActivityIntent.putExtra(Intent.EXTRA_TEXT, textEntered);

                startActivity(mainActivityIntent);
            }
        });

        changeActivityButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = MainActivity.this;
                Class destinationActivity3 = MainActivity3.class;
                Intent mainActivityIntent = new Intent(context, destinationActivity3);
                startActivity(mainActivityIntent);
            }
        });
    }
}